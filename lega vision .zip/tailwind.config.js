/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        white: "#fff",
        brand: "#437df9",
        "dark-grey": "#434344",
        black: "#000",
        mediumblue: "#1d3cdd",
        gray: {
          "100": "#908d8d",
          "200": "#212121",
          "300": "#1a1a1a",
          "400": "#0c1621",
        },
        "soft-grey": "#5d5858",
        red: "#f92c2c",
        "hover-effect": "#027184",
        dimgray: "#5c5c5c",
        "real-gold": "#edcea5",
        whitesmoke: "#f2f2f2",
        "light-grey": "#8b8b8b",
      },
      spacing: {},
      fontFamily: {
        "saira-condensed": "'Saira Condensed'",
        inter: "Inter",
      },
      borderRadius: {
        "9xl": "28px",
      },
    },
    fontSize: {
      "7xl": "26px",
      "11xl": "30px",
      "51xl": "70px",
      "41xl": "60px",
      "8xl": "27px",
      "13xl": "32px",
      "21xl": "40px",
      inherit: "inherit",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
