import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import SignUp1 from "./SignUp1";
import FrameComponent from "./FrameComponent";

const HomeContainer: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpContainerClick = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/desktop-1");
  }, [navigate]);

  const onAboutUsContainerClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onTeamTextClick = useCallback(() => {
    navigate("/team");
  }, [navigate]);

  const onBlogNewsTextClick = useCallback(() => {
    navigate("/blognews");
  }, [navigate]);

  return (
    <div className="absolute top-[-40px] left-[-2px] w-[1442px] h-[357px] overflow-hidden text-center text-11xl text-black font-saira-condensed">
      <div className="absolute top-[0px] left-[0px] w-[1442px] h-[348px] overflow-hidden">
        <div className="absolute w-full top-[40px] right-[0px] left-[0px] bg-white shadow-[0px_4px_0px_rgba(0,_0,_0,_0.25)] h-[308px]" />
      </div>
      <img
        className="absolute top-[0px] left-[70px] w-[567px] h-[357px] object-cover"
        alt=""
        src="/20230325-184847removebgpreview-1@2x.png"
      />
      <div className="absolute top-[0px] left-[694px] w-[570px] h-[247px] overflow-hidden">
        <div className="absolute top-[178px] left-[0px] flex flex-row items-center justify-start gap-[27px]">
          <div className="shrink-0 flex flex-row items-start justify-start gap-[27px]">
            <b
              className="relative tracking-[0.02em] cursor-pointer"
              onClick={onHomeTextClick}
            >
              Home
            </b>
            <div
              className="w-[99px] flex flex-col items-center justify-center cursor-pointer"
              onClick={onAboutUsContainerClick}
            >
              <b className="relative tracking-[0.02em]">About us</b>
            </div>
            <b
              className="relative tracking-[0.02em] cursor-pointer"
              onClick={onTeamTextClick}
            >
              Team
            </b>
            <b
              className="relative tracking-[0.02em] cursor-pointer"
              onClick={onBlogNewsTextClick}
            >{`Blog/News `}</b>
          </div>
          <SignUp1
            signupButtonText="Sign up"
            propBackgroundColor="#027184"
            propFlexShrink="0"
            propPadding="11px 17px"
            propHeight="unset"
            propAlignSelf="unset"
            propMarginLeft="unset"
            propColor="#000"
            propLineHeight="unset"
            onSignUpContainerClick={onSignUpContainerClick}
          />
        </div>
      </div>
      <div className="absolute top-[0px] left-[744px] w-[468px] h-[157px] overflow-hidden">
        <FrameComponent
          propAlignSelf="unset"
          propPosition="absolute"
          propTop="98px"
          propLeft="0px"
        />
      </div>
      <div className="absolute top-[0px] left-[654px] w-[633px] h-[304px] overflow-hidden">
        <img
          className="absolute top-[281px] left-[0px] w-[633px] h-[23px] object-cover"
          alt=""
          src="/20230325-191050removebgpreview-1@2x.png"
        />
      </div>
    </div>
  );
};

export default HomeContainer;
