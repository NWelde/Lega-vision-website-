import { FunctionComponent, useMemo, type CSSProperties } from "react";

type SignUp1Type = {
  signupButtonText?: string;

  /** Style props */
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propFlexShrink?: CSSProperties["flexShrink"];
  propPadding?: CSSProperties["padding"];
  propHeight?: CSSProperties["height"];
  propAlignSelf?: CSSProperties["alignSelf"];
  propMarginLeft?: CSSProperties["marginLeft"];
  propColor?: CSSProperties["color"];
  propLineHeight?: CSSProperties["lineHeight"];

  /** Action props */
  onSignUpContainerClick?: () => void;
};

const SignUp1: FunctionComponent<SignUp1Type> = ({
  signupButtonText,
  propBackgroundColor,
  propFlexShrink,
  propPadding,
  propHeight,
  propAlignSelf,
  propMarginLeft,
  propColor,
  propLineHeight,
  onSignUpContainerClick,
}) => {
  const signUpStyle: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
      flexShrink: propFlexShrink,
      padding: propPadding,
      height: propHeight,
      alignSelf: propAlignSelf,
      marginLeft: propMarginLeft,
    };
  }, [
    propBackgroundColor,
    propFlexShrink,
    propPadding,
    propHeight,
    propAlignSelf,
    propMarginLeft,
  ]);

  const signUp1Style: CSSProperties = useMemo(() => {
    return {
      color: propColor,
      lineHeight: propLineHeight,
    };
  }, [propColor, propLineHeight]);

  return (
    <div
      className="rounded-9xl bg-red shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] shrink-0 flex flex-row items-center justify-center py-[11px] px-[17px] mix-blend-hard-light cursor-pointer text-center text-11xl text-black font-saira-condensed"
      onClick={onSignUpContainerClick}
      style={signUpStyle}
    >
      <b className="relative tracking-[0.02em]" style={signUp1Style}>
        {signupButtonText}
      </b>
    </div>
  );
};

export default SignUp1;
