import { FunctionComponent, useMemo, type CSSProperties } from "react";

type FrameComponentType = {
  /** Style props */
  propAlignSelf?: CSSProperties["alignSelf"];
  propPosition?: CSSProperties["position"];
  propTop?: CSSProperties["top"];
  propLeft?: CSSProperties["left"];
};

const FrameComponent: FunctionComponent<FrameComponentType> = ({
  propAlignSelf,
  propPosition,
  propTop,
  propLeft,
}) => {
  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      position: propPosition,
      top: propTop,
      left: propLeft,
    };
  }, [propAlignSelf, propPosition, propTop, propLeft]);

  return (
    <div
      className="self-stretch rounded-2xl flex flex-row items-center justify-between py-1.5 px-[79px] text-center text-11xl text-soft-grey font-saira-condensed"
      style={frameDivStyle}
    >
      <img
        className="relative w-7 h-[35px] object-cover"
        alt=""
        src="/image-1@2x.png"
      />
      <b className="relative tracking-[0.02em] whitespace-pre-wrap">
        Search for an experience
      </b>
    </div>
  );
};

export default FrameComponent;
