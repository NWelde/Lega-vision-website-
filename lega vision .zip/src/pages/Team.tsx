import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import SignUp1 from "../components/SignUp1";
import FrameComponent from "../components/FrameComponent";

const Team: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpContainerClick = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/desktop-1");
  }, [navigate]);

  const onAboutUsContainerClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onBlogNewsTextClick = useCallback(() => {
    navigate("/blognews");
  }, [navigate]);

  return (
    <div className="relative bg-gray-200 w-full h-[4535px] overflow-hidden text-center text-21xl text-gray-400 font-saira-condensed">
      <div className="absolute top-[980px] left-[370px] bg-whitesmoke w-[700px] h-[649.5px]" />
      <div className="absolute top-[2083px] left-[370px] bg-whitesmoke w-[700px] h-[649.5px]" />
      <div className="absolute top-[3183px] left-[370px] bg-whitesmoke w-[700px] h-[649.5px]" />
      <div className="absolute w-[calc(100%_+_2px)] top-[0px] right-[0px] left-[-2px] bg-white shadow-[0px_4px_0px_rgba(255,_255,_255,_0.25)] h-[308px]" />
      <img
        className="absolute top-[-40px] left-[68px] w-[567px] h-[357px] object-cover"
        alt=""
        src="/20230325-184847removebgpreview-1@2x.png"
      />
      <div className="absolute top-[138px] left-[692px] flex flex-row items-center justify-start gap-[27px] text-11xl text-black">
        <div className="shrink-0 flex flex-row items-start justify-start gap-[27px]">
          <b
            className="relative tracking-[0.02em] cursor-pointer"
            onClick={onHomeTextClick}
          >
            Home
          </b>
          <div
            className="w-[99px] flex flex-col items-center justify-center cursor-pointer"
            onClick={onAboutUsContainerClick}
          >
            <b className="relative tracking-[0.02em]">About us</b>
          </div>
          <b className="relative tracking-[0.02em] text-hover-effect">Team</b>
          <b
            className="relative tracking-[0.02em] cursor-pointer"
            onClick={onBlogNewsTextClick}
          >{`Blog/News `}</b>
        </div>
        <SignUp1
          signupButtonText="Sign up"
          propBackgroundColor="#f92c2c"
          propFlexShrink="0"
          propPadding="11px 17px"
          propHeight="unset"
          propAlignSelf="unset"
          propMarginLeft="unset"
          propColor="#000"
          propLineHeight="unset"
          onSignUpContainerClick={onSignUpContainerClick}
        />
      </div>
      <FrameComponent
        propAlignSelf="unset"
        propPosition="absolute"
        propTop="58px"
        propLeft="742px"
      />
      <img
        className="absolute top-[241px] left-[652px] w-[633px] h-[23px] object-cover"
        alt=""
        src="/20230325-191050removebgpreview-1@2x.png"
      />
      <div className="absolute w-full right-[0px] bottom-[0px] left-[0px] bg-brand h-[227px]" />
      <div className="absolute bottom-[13px] left-[182px] flex flex-row items-end justify-start gap-[415px] text-7xl text-white">
        <div className="shrink-0 flex flex-row items-start justify-start gap-[49px]">
          <b className="relative tracking-[0.02em]">{`Terms & Conditions`}</b>
          <b className="relative tracking-[0.02em]">{`Privacy & Policy`}</b>
        </div>
        <div className="shrink-0 flex flex-row items-start justify-start gap-[23px]">
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-7@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-6@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-5@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-8@2x.png"
          />
        </div>
      </div>
      <div className="absolute top-[506px] left-[578px] text-[65px] tracking-[0.05em] font-extrabold text-brand inline-block w-[292px]">
        Our Team
      </div>
      <img
        className="absolute top-[338px] left-[529px] w-[353px] h-[219px] object-cover"
        alt=""
        src="/20230325-190639removebgpreview-1@2x.png"
      />
      <div className="absolute top-[793.5px] left-[558.5px] flex flex-row items-start justify-start p-2.5 border-[3px] border-solid border-real-gold">
        <img
          className="relative w-[300px] h-[300px] object-cover"
          alt=""
          src="/rectangle-5@2x.png"
        />
      </div>
      <div className="absolute top-[1896.5px] left-[558.5px] flex flex-row items-start justify-start p-2.5 border-[3px] border-solid border-real-gold">
        <img
          className="relative w-[300px] h-[300px] object-cover"
          alt=""
          src="/rectangle-5@2x.png"
        />
      </div>
      <div className="absolute top-[2996.5px] left-[558.5px] flex flex-row items-start justify-start p-2.5 border-[3px] border-solid border-real-gold">
        <img
          className="relative w-[300px] h-[300px] object-cover"
          alt=""
          src="/rectangle-5@2x.png"
        />
      </div>
      <div className="absolute top-[1152px] left-[424px] flex flex-col items-center justify-start gap-[27px]">
        <div className="shrink-0 flex flex-col items-center justify-start gap-[10px]">
          <b className="relative tracking-[0.01em] leading-[109.5%] capitalize">
            Girum Getachew
          </b>
          <b className="relative text-13xl tracking-[0.01em] leading-[109.5%] text-gray-100">
            Chairman of the Board of Directors and Co-founder
          </b>
        </div>
        <div className="relative text-8xl tracking-[0.01em] leading-[109.5%] text-dimgray inline-block w-[561px]">
          Girum is the driving force behind LEGA, serving as the Chairman of the
          Board of Directors and a co-founder. With a vision for positive change
          and a commitment to educational empowerment, Girum plays a pivotal
          role in guiding the organization's strategic direction. His leadership
          inspires the team to continue making a lasting impact on the lives of
          young individuals.
        </div>
      </div>
      <div className="absolute top-[2254px] left-[420px] flex flex-col items-center justify-start gap-[27px]">
        <div className="shrink-0 flex flex-col items-center justify-start gap-[10px]">
          <b className="relative tracking-[0.01em] leading-[109.5%] capitalize">
            Kidus Mengistu
          </b>
          <b className="relative text-13xl tracking-[0.01em] leading-[109.5%] text-gray-100">
            Secretary of the Board of Directors and Co-founder
          </b>
        </div>
        <div className="relative text-8xl tracking-[0.01em] leading-[109.5%] text-dimgray inline-block w-[561px]">
          Kidus, as the Secretary of the Board of Directors and co-founder,
          brings a wealth of dedication and organizational skills to LEGA. His
          passion for education and youth development has been instrumental in
          shaping the initiatives and programs that LEGA offers. Kidus is a key
          contributor to the vision of creating a platform that helps young
          minds discover their purpose and potential.
        </div>
      </div>
      <div className="absolute top-[3354px] left-[440px] flex flex-col items-center justify-start gap-[27px]">
        <div className="shrink-0 flex flex-col items-center justify-start gap-[10px]">
          <b className="relative tracking-[0.01em] leading-[109.5%] capitalize">
            Ruth Alemu
          </b>
          <b className="relative text-13xl tracking-[0.01em] leading-[109.5%] capitalize text-gray-100">
            Vice Chairman of the Board of Directors
          </b>
        </div>
        <div className="relative text-8xl tracking-[0.01em] leading-[109.5%] text-dimgray inline-block w-[561px]">
          Ruth serves as the Vice Chairman of the Board of Directors, bringing
          valuable insights and expertise to LEGA. Her commitment to the
          organization's mission, coupled with her leadership skills,
          contributes to the successful execution of our programs. Ruth plays a
          vital role in ensuring that LEGA remains a beacon of support and
          guidance for students navigating their educational journey.
        </div>
      </div>
      <div className="absolute top-[2616px] left-[634px] flex flex-row items-center justify-start gap-[14px]">
        <img
          className="relative w-10 h-10 object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
        <img
          className="relative w-[62px] h-[62px] object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
        <img
          className="relative w-[31px] h-[31px] object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
      </div>
      <div className="absolute top-[3731px] left-[635px] flex flex-row items-center justify-start gap-[14px]">
        <img
          className="relative w-10 h-10 object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
        <img
          className="relative w-[62px] h-[62px] object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
        <img
          className="relative w-[31px] h-[31px] object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
      </div>
      <div className="absolute top-[1515px] left-[637px] flex flex-row items-center justify-start gap-[14px]">
        <img
          className="relative w-10 h-10 object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
        <img
          className="relative w-[62px] h-[62px] object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
        <img
          className="relative w-[31px] h-[31px] object-cover"
          alt=""
          src="/mask-group@2x.png"
        />
      </div>
    </div>
  );
};

export default Team;
