import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import SignUp1 from "../components/SignUp1";
import FrameComponent from "../components/FrameComponent";

const BlogNews: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpContainerClick = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/desktop-1");
  }, [navigate]);

  const onAboutUsContainerClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[2736px] overflow-hidden text-center text-11xl text-black font-saira-condensed">
      <div className="absolute w-[calc(100%_+_2px)] top-[0px] right-[0px] left-[-2px] bg-white shadow-[0px_4px_0px_rgba(0,_0,_0,_0.25)] h-[308px]" />
      <img
        className="absolute top-[-40px] left-[68px] w-[567px] h-[357px] object-cover"
        alt=""
        src="/20230325-184847removebgpreview-1@2x.png"
      />
      <div className="absolute w-full right-[0px] bottom-[0px] left-[0px] bg-brand h-[227px]" />
      <div className="absolute top-[138px] left-[692px] flex flex-row items-center justify-start gap-[27px]">
        <div className="shrink-0 flex flex-row items-start justify-start gap-[27px]">
          <b
            className="relative tracking-[0.02em] cursor-pointer"
            onClick={onHomeTextClick}
          >
            Home
          </b>
          <div
            className="w-[99px] flex flex-col items-center justify-center cursor-pointer"
            onClick={onAboutUsContainerClick}
          >
            <b className="relative tracking-[0.02em]">About us</b>
          </div>
          <b className="relative tracking-[0.02em]">Team</b>
          <b className="relative tracking-[0.02em] text-hover-effect">{`Blog/News `}</b>
        </div>
        <SignUp1
          signupButtonText="Sign up"
          propBackgroundColor="#f92c2c"
          propFlexShrink="0"
          propPadding="11px 17px"
          propHeight="unset"
          propAlignSelf="unset"
          propMarginLeft="unset"
          propColor="#000"
          propLineHeight="unset"
          onSignUpContainerClick={onSignUpContainerClick}
        />
      </div>
      <FrameComponent
        propAlignSelf="unset"
        propPosition="absolute"
        propTop="58px"
        propLeft="742px"
      />
      <img
        className="absolute top-[241px] left-[652px] w-[633px] h-[23px] object-cover"
        alt=""
        src="/20230325-191050removebgpreview-1@2x.png"
      />
      <div className="absolute bottom-[17px] left-[164px] flex flex-row items-end justify-start gap-[415px] text-7xl text-white">
        <div className="shrink-0 flex flex-row items-start justify-start gap-[49px]">
          <b className="relative tracking-[0.02em]">{`Terms & Conditions`}</b>
          <b className="relative tracking-[0.02em]">{`Privacy & Policy`}</b>
        </div>
        <div className="shrink-0 flex flex-row items-start justify-start gap-[23px]">
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-7@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-6@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-5@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-8@2x.png"
          />
        </div>
      </div>
      <b className="absolute top-[1181px] left-[489px] text-51xl tracking-[0.01em] leading-[109.5%] capitalize text-transparent !bg-clip-text [background:linear-gradient(90deg,_#0051ff,_rgba(81,_128,_228,_0.57))] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] text-left">
        Blogs Coming Soon...
      </b>
      <div className="absolute top-[658px] left-[157px] text-[47px] tracking-[0.01em] leading-[109.5%] capitalize font-semibold">
        <p className="[margin-block-start:0] [margin-block-end:10px]">
          Stay informed with the latest news and updates from LEGA.
        </p>
        <p className="[margin-block-start:0] [margin-block-end:10px]">{` Our blog shares stories of success, highlights from events, `}</p>
        <p className="[margin-block-start:0] [margin-block-end:10px]">{`and behind-the-scenes glimpses into our work. `}</p>
        <p className="m-0">Join us on our journey of impact.</p>
      </div>
    </div>
  );
};

export default BlogNews;
