import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import SignUp1 from "../components/SignUp1";
import FrameComponent from "../components/FrameComponent";

const AboutUs: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpContainerClick = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/desktop-1");
  }, [navigate]);

  const onAboutUsContainerClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onBlogNewsTextClick = useCallback(() => {
    navigate("/blognews");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[3906px] overflow-hidden text-left text-7xl text-black font-saira-condensed">
      <div className="absolute w-[calc(100%_+_2px)] top-[0px] right-[0px] left-[-2px] bg-white shadow-[0px_4px_0px_rgba(0,_0,_0,_0.25)] h-[308px]" />
      <img
        className="absolute top-[-40px] left-[68px] w-[567px] h-[357px] object-cover"
        alt=""
        src="/20230325-184847removebgpreview-1@2x.png"
      />
      <div className="absolute w-full right-[0px] bottom-[0px] left-[0px] bg-brand h-[227px]" />
      <div className="absolute top-[138px] left-[692px] flex flex-row items-center justify-start gap-[27px] text-center text-11xl">
        <div className="shrink-0 flex flex-row items-start justify-start gap-[27px]">
          <b
            className="relative tracking-[0.02em] cursor-pointer"
            onClick={onHomeTextClick}
          >
            Home
          </b>
          <div
            className="w-[99px] flex flex-col items-center justify-center cursor-pointer text-hover-effect"
            onClick={onAboutUsContainerClick}
          >
            <b className="relative tracking-[0.02em]">About us</b>
          </div>
          <b className="relative tracking-[0.02em]">Team</b>
          <b
            className="relative tracking-[0.02em] cursor-pointer"
            onClick={onBlogNewsTextClick}
          >{`Blog/News `}</b>
        </div>
        <SignUp1
          signupButtonText="Sign up"
          propBackgroundColor="#f92c2c"
          propFlexShrink="0"
          propPadding="11px 17px"
          propHeight="unset"
          propAlignSelf="unset"
          propMarginLeft="unset"
          propColor="#000"
          propLineHeight="unset"
          onSignUpContainerClick={onSignUpContainerClick}
        />
      </div>
      <FrameComponent
        propAlignSelf="unset"
        propPosition="absolute"
        propTop="58px"
        propLeft="742px"
      />
      <img
        className="absolute top-[241px] left-[652px] w-[633px] h-[23px] object-cover"
        alt=""
        src="/20230325-191050removebgpreview-1@2x.png"
      />
      <b className="absolute top-[474px] left-[176px] text-[90px] tracking-[0.02em] leading-[109.5%] text-brand">
        <p className="[margin-block-start:0] [margin-block-end:16px]">
          By youth, for
        </p>
        <p className="m-0">youth</p>
      </b>
      <b className="absolute top-[925px] left-[235px] text-41xl tracking-[0.02em] leading-[109.5%] inline-block w-[492px] h-[81px]">
        Mission Statement
      </b>
      <b className="absolute top-[2125px] left-[235px] text-41xl tracking-[0.02em] leading-[109.5%] inline-block w-[492px] h-[81px]">
        History
      </b>
      <img
        className="absolute top-[402px] left-[754px] w-[497px] h-[458px] object-cover"
        alt=""
        src="/76949581youthstudenteducationfashionremovebgpreview-1@2x.png"
      />
      <b className="absolute top-[1030px] left-[181px] leading-[170%] inline-block font-inter text-dark-grey w-[1075px] h-[977px]">
        <p className="m-0">
          "At LEGA, we are a non-profit organization dedicated to transforming
          lives through education. Our primary focus lies in enriching the
          awareness and fostering the career development of young individuals.
          With a commitment to empowering the youth, we aim to guide them
          towards discovering their purpose early on, ensuring they invest their
          time wisely in meaningful pursuits.
        </p>
        <p className="m-0">{` `}</p>
        <p className="m-0">
          Our mission is to work collaboratively with students, particularly in
          high schools, providing them with the necessary tools and resources to
          develop skills across various domains. We believe in nurturing talents
          and honing capabilities that extend beyond the academic realm. By
          emphasizing early engagement and purposeful exploration, we strive to
          equip the youth with the skills and knowledge needed to meet their
          life goals.
        </p>
        <p className="m-0">{` `}</p>
        <p className="m-0">
          LEGA is dedicated to creating a supportive and inspirational
          environment for students, encouraging them to embrace learning
          opportunities and personal development initiatives. Through targeted
          educational programs, mentorship, and skill-building activities, we
          aim to empower the youth to make informed decisions about their future
          and contribute meaningfully to society.
        </p>
        <p className="m-0">&nbsp;</p>
        <p className="m-0">
          {" "}
          Join us on this journey of educational empowerment, where we believe
          that investing in the potential of today's youth is an investment in a
          brighter and more prosperous future for all."
        </p>
      </b>
      <b className="absolute top-[2242px] left-[181px] leading-[170%] inline-block font-inter text-dark-grey w-[1075px] h-[1242px]">
        <p className="m-0">
          "LEGA, a transformative initiative founded by two visionary
          individuals, Kidus and Girum, traces its origins back to their high
          school years. As high school students, Kidus and Girum shared a common
          passion: to illuminate the path for their peers and ensure that others
          wouldn't encounter the same challenges they faced. Driven by their
          commitment to guiding young minds, they laid the foundation for this
          exceptional NGO.
        </p>
        <p className="m-0">{` `}</p>
        <p className="m-0">
          Founded during their time in high school, LEGA emerged from the
          personal experiences and lessons learned by Kidus and Girum. Their
          shared vision was born out of a desire to create an organization that
          would serve as a guiding force for young individuals, helping them
          find purpose and steering them away from avoidable pitfalls.
        </p>
        <p className="m-0">&nbsp;</p>
        <p className="m-0">
          Fast forward to the present, Kidus and Girum have evolved into
          accomplished engineers, currently pursuing their academic and
          professional journeys at the Addis Ababa Science and Technology
          University (AASTU). Their commitment to educational empowerment and
          youth development remains unwavering, and their experiences as
          engineers further enrich the guidance they provide through LEGA.
        </p>
        <p className="m-0">{` `}</p>
        <p className="m-0">{`LEGA, under the leadership of Kidus and Girum, has become a dynamic force, positively impacting the lives of countless young individuals. Their dedication to the cause has fueled the growth and success of the organization, making it a trusted ally for students on their journey to self-discovery and purposeful living. `}</p>
        <p className="m-0">&nbsp;</p>
        <p className="m-0">
          Today, as Kidus and Girum continue to thrive in their engineering
          careers at AASTU, their legacy lives on through LEGA, which stands as
          a testament to their vision, passion, and ongoing commitment to
          shaping a brighter future for the youth of tomorrow."
        </p>
      </b>
      <div className="absolute top-[3842px] left-[181px] flex flex-row items-end justify-start gap-[415px] text-center text-white">
        <div className="shrink-0 flex flex-row items-start justify-start gap-[49px]">
          <b className="relative tracking-[0.02em]">{`Terms & Conditions`}</b>
          <b className="relative tracking-[0.02em]">{`Privacy & Policy`}</b>
        </div>
        <div className="shrink-0 flex flex-row items-start justify-start gap-[23px]">
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-7@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-6@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-5@2x.png"
          />
          <img
            className="relative w-[50px] h-[50px] object-cover"
            alt=""
            src="/image-8@2x.png"
          />
        </div>
      </div>
    </div>
  );
};

export default AboutUs;
