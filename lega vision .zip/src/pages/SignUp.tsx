import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import HomeContainer from "../components/HomeContainer";

const SignUp: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpContainerClick = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onSignUpHereClick = useCallback(() => {
    navigate("/sign-up-form");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[2241px] overflow-hidden text-left text-7xl text-black font-inter">
      <b className="absolute top-[487px] left-[262px] text-41xl tracking-[0.02em] leading-[109.5%] font-saira-condensed">
        Login to Lega Vision Initiatives
      </b>
      <div className="absolute top-[965px] left-[635px] leading-[170%] text-dark-grey">
        <span>{`Having some trouble? `}</span>
        <span className="text-brand">Reset Password</span>
      </div>
      <div className="absolute top-[1040px] left-[319px] rounded-xl bg-brand flex flex-row items-center justify-center py-2.5 px-[354px] text-white">
        <b className="relative leading-[170%]">Login</b>
      </div>
      <div className="absolute top-[584px] left-[259px] w-[455px] h-11 overflow-hidden text-dark-grey">
        <div className="absolute top-[0px] left-[0px] leading-[170%]">{`Don’t have an account? `}</div>
        <div
          className="absolute top-[0px] left-[300px] leading-[170%] text-brand cursor-pointer"
          onClick={onSignUpHereClick}
        >
          Sign up here
        </div>
      </div>
      <div className="absolute top-[680px] left-[262px] w-[673px] h-14 overflow-hidden">
        <div className="absolute top-[6px] left-[0px] leading-[170%]">
          Full Name*
        </div>
        <div className="absolute top-[0px] left-[219px] rounded-xl flex flex-row items-center justify-center py-1.5 px-[104px] text-light-grey border-[1px] border-solid border-light-grey">
          <div className="relative leading-[170%]">Enter your full name</div>
        </div>
      </div>
      <div className="absolute top-[767px] left-[262px] w-[675px] h-14 overflow-hidden">
        <div className="absolute top-[6px] left-[0px] leading-[170%]">
          Email*
        </div>
        <div className="absolute top-[0px] left-[220px] rounded-xl flex flex-row items-center justify-center py-1.5 px-[104px] text-light-grey border-[1px] border-solid border-light-grey">
          <div className="relative leading-[170%]">
            <span>Enter your email</span>
            <span className="text-white">____</span>
            <span>{` `}</span>
          </div>
        </div>
      </div>
      <div className="absolute top-[857px] left-[263px] w-[681px] h-14 overflow-hidden">
        <div className="absolute top-[6px] left-[0px] leading-[170%]">
          Password*
        </div>
        <div className="absolute top-[0px] left-[220px] rounded-xl flex flex-row items-center justify-center py-1.5 px-[104px] text-light-grey border-[1px] border-solid border-light-grey">
          <div className="relative leading-[170%]">Enter your password</div>
        </div>
      </div>
      <div className="absolute w-full right-[0px] bottom-[0px] left-[0px] bg-brand h-[227px] overflow-hidden text-center text-white font-saira-condensed">
        <div className="absolute bottom-[13px] left-[182px] flex flex-row items-end justify-start gap-[415px]">
          <div className="shrink-0 flex flex-row items-start justify-start gap-[49px]">
            <b className="relative tracking-[0.02em]">{`Terms & Conditions`}</b>
            <b className="relative tracking-[0.02em]">{`Privacy & Policy`}</b>
          </div>
          <div className="shrink-0 flex flex-row items-start justify-start gap-[23px]">
            <img
              className="relative w-[50px] h-[50px] object-cover"
              alt=""
              src="/image-7@2x.png"
            />
            <img
              className="relative w-[50px] h-[50px] object-cover"
              alt=""
              src="/image-6@2x.png"
            />
            <img
              className="relative w-[50px] h-[50px] object-cover"
              alt=""
              src="/image-5@2x.png"
            />
            <img
              className="relative w-[50px] h-[50px] object-cover"
              alt=""
              src="/image-8@2x.png"
            />
          </div>
        </div>
      </div>
      <HomeContainer />
    </div>
  );
};

export default SignUp;
